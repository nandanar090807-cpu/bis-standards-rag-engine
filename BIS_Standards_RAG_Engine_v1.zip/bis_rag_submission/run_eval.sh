#!/usr/bin/env bash
# BIS Hackathon — one-command evaluation
# Usage: bash run_eval.sh [input_file] [output_file]
#
# Defaults match the judge command exactly:
#   python inference.py --input hidden_private_dataset.json --output team_results.json

set -e

INPUT="${1:-hidden_private_dataset.json}"
OUTPUT="${2:-team_results.json}"

if [ ! -f "$INPUT" ]; then
    echo "ERROR: Input file '$INPUT' not found."
    echo "Usage: bash run_eval.sh <input_json> [output_json]"
    echo "Example: bash run_eval.sh data/public_test_set.json results.json"
    exit 1
fi

echo "=== BIS RAG Inference ==="
python3 inference.py --input "$INPUT" --output "$OUTPUT"

RESULT_COUNT=$(python3 -c "import json; d=json.load(open('$OUTPUT')); print(len(d))" 2>/dev/null || echo 0)
if [ "$RESULT_COUNT" -eq 0 ]; then
    echo "ERROR: Inference produced 0 results. Check the input file and ChromaDB index."
    exit 1
fi

echo ""
echo "=== Evaluation Results ==="
python3 eval_script.py --results "$OUTPUT"
