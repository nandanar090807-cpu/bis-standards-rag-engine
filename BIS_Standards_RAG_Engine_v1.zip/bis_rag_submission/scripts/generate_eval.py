"""
Synthetic evaluation set generator for BIS RAG pipeline.

Samples IS standards from extracted_standards.json across all building
material categories, calls Gemini to write a realistic MSE product
description for each, and merges with the existing 10 public queries
to produce a 50-query eval_ready.json.

Usage:
    python scripts/generate_eval.py
    python scripts/generate_eval.py --count 40 --out data/eval_ready.json

Requires GEMINI_API_KEY in .env (or environment).
"""
import argparse
import json
import os
import random
random.seed(42)  # fix: ensures reproducible synthetic eval set
import re
import sys
import time

import requests
from dotenv import load_dotenv

load_dotenv()

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(_ROOT, "src"))

from config import GEMINI_API_KEY, GEMINI_MODEL, GENERATOR_TIMEOUT

# NOTE: This duplicates GEMINI_URL from generator.py.
# If the API endpoint changes, update both files.
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```\s*$", re.MULTILINE)

CATEGORY_KEYWORDS = {
    "cement":      ["cement", "portland", "clinker", "pozzolana", "slag cement", "fly ash"],
    "aggregate":   ["aggregate", "gravel", "sand", "coarse", "fine aggr", "crushed stone"],
    "steel":       ["steel", "reinforcement", "rebar", "bar", "wire", "strand", "tendon"],
    "concrete":    ["concrete", "mortar", "masonry", "grout", "screed", "precast", "block"],
    "brick":       ["brick", "tile", "clay", "burnt clay", "earthenware"],
    "pipe":        ["pipe", "tube", "culvert", "conduit", "drainage"],
}

_SYSTEM_PROMPT = """\
You are a quality tester for a BIS (Bureau of Indian Standards) compliance tool.

Given an IS standard code, title, and a summary, write a realistic product description
that a small Indian manufacturer or procurement officer might submit to find this standard.

Rules:
1. Write 2-3 natural sentences as if the user does not know the IS code.
2. Do NOT mention the IS code number or the standard title verbatim.
3. Use real manufacturing/procurement language (grades, applications, material properties).
4. Return ONLY the product description string. No JSON, no explanation, no quotes.\
"""


def classify(chunk: dict) -> str:
    text = (chunk.get("title", "") + " " + chunk.get("text", "")).lower()
    for cat, kws in CATEGORY_KEYWORDS.items():
        if any(kw in text for kw in kws):
            return cat
    return "general"


def generate_query(chunk: dict) -> str | None:
    if not GEMINI_API_KEY:
        return None

    user_text = (
        f"IS Code: {chunk['is_code']}\n"
        f"Title: {chunk['title']}\n"
        f"Summary: {chunk['text'][:600]}"
    )
    payload = {
        "system_instruction": {"parts": [{"text": _SYSTEM_PROMPT}]},
        "contents": [{"role": "user", "parts": [{"text": user_text}]}],
        "generationConfig": {"temperature": 0.7, "maxOutputTokens": 200},
    }
    headers = {
        "Content-Type": "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
    }

    for attempt in range(3):
        try:
            resp = requests.post(
                GEMINI_URL, json=payload, headers=headers, timeout=GENERATOR_TIMEOUT
            )
            if resp.status_code == 200:
                data = resp.json()
                candidates = data.get("candidates", [])
                if not candidates:
                    return None
                raw = candidates[0]["content"]["parts"][0]["text"].strip()
                raw = _FENCE_RE.sub("", raw).strip()
                return raw if raw else None

            if resp.status_code in (429, 500, 503):
                time.sleep(2 * (attempt + 1))
                continue

            return None

        except Exception as exc:
            print(f"  [warn] Gemini error: {exc}")
            time.sleep(2)

    return None


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--count",  type=int, default=40,
                        help="Number of synthetic queries to generate")
    parser.add_argument("--out",    default=os.path.join(_ROOT, "data", "eval_ready.json"))
    parser.add_argument("--standards", default=os.path.join(_ROOT, "data", "extracted_standards.json"))
    parser.add_argument("--public", default=os.path.join(_ROOT, "data", "public_test_set.json"))
    parser.add_argument("--seed",   type=int, default=42)
    args = parser.parse_args()

    random.seed(args.seed)

    with open(args.standards, encoding="utf-8") as f:
        standards = json.load(f)

    with open(args.public, encoding="utf-8") as f:
        public_queries = json.load(f)

    # Exclude standards already in the public test set
    public_codes = {
        q["expected_standards"][0].replace(" ", "").lower()
        for q in public_queries
        if q.get("expected_standards")
    }

    pool = [
        c for c in standards
        if c.get("text") and len(c["text"]) > 100
        and c["is_code"].replace(" ", "").lower() not in public_codes
        and classify(c) != "general"
    ]

    print(f"[gen] Pool size after filtering: {len(pool)} standards")

    # Stratified sample across categories
    by_cat: dict = {}
    for c in pool:
        cat = classify(c)
        by_cat.setdefault(cat, []).append(c)

    cats = list(by_cat.keys())
    per_cat = max(1, args.count // len(cats))
    sampled = []
    for cat in cats:
        items = by_cat[cat]
        random.shuffle(items)
        sampled.extend(items[:per_cat])
    # Top up to args.count if rounding left gaps
    remaining = [c for c in pool if c not in sampled]
    random.shuffle(remaining)
    sampled.extend(remaining[: args.count - len(sampled)])
    sampled = sampled[: args.count]

    print(f"[gen] Generating {len(sampled)} synthetic queries via Gemini ...")

    synthetic = []
    for idx, chunk in enumerate(sampled, 1):
        print(f"  [{idx}/{len(sampled)}] {chunk['is_code']} ({classify(chunk)})")
        query_text = generate_query(chunk)
        if not query_text:
            # Fallback: use a template query if Gemini unavailable
            query_text = (
                f"We manufacture products related to {chunk['title'].lower().strip()}. "
                "Which BIS standard applies?"
            )
            print(f"    -> fallback query used")
        else:
            print(f"    -> {query_text[:80]}...")

        synthetic.append({
            "id": f"SYN-{idx:02d}",
            "query": query_text,
            "expected_standards": [chunk["is_code"]],
        })
        time.sleep(0.3)  # gentle rate limit

    # Merge public (10) + synthetic (40) = 50
    combined = public_queries + synthetic
    print(f"\n[gen] Total queries: {len(combined)} (10 public + {len(synthetic)} synthetic)")

    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(combined, f, indent=2, ensure_ascii=False)

    print(f"[gen] Written to {args.out}")


if __name__ == "__main__":
    main()
