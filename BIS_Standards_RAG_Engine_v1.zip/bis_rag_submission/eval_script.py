import json
import argparse
import sys


def normalize_std(std_string):
    """Normalize IS code for comparison: strip spaces and lowercase."""
    return str(std_string).replace(" ", "").lower()


def evaluate_results(results_file):
    try:
        with open(results_file, "r") as f:
            data = json.load(f)
    except Exception as e:
        print(f"Error reading results file: {e}")
        sys.exit(1)

    total_queries = len(data)
    if total_queries == 0:
        print("No queries found in the result file.")
        sys.exit(1)

    hits_at_3   = 0
    mrr_sum_at_5 = 0.0
    latency_entries = []

    for item in data:
        expected  = set(normalize_std(s) for s in item.get("expected_standards", []))
        retrieved = [normalize_std(s) for s in item.get("retrieved_standards", [])]
        latency   = item.get("latency_seconds")

        if latency is not None:
            latency_entries.append(latency)

        # Hit Rate @3: at least 1 expected standard in top 3
        if any(s in expected for s in retrieved[:3]):
            hits_at_3 += 1

        # MRR @5: reciprocal rank of first correct hit in top 5
        for rank, s in enumerate(retrieved[:5], start=1):
            if s in expected:
                mrr_sum_at_5 += 1.0 / rank
                break

    hit_rate_3  = (hits_at_3 / total_queries) * 100
    mrr_5       = mrr_sum_at_5 / total_queries
    avg_latency = sum(latency_entries) / len(latency_entries) if latency_entries else 0.0

    sep = "=" * 42
    print(sep)
    print("   BIS HACKATHON EVALUATION RESULTS")
    print(sep)
    print(f"Total Queries Evaluated : {total_queries}")
    print(f"Hit Rate @3             : {hit_rate_3:.2f}% \t(Target: >80%)")
    print(f"MRR @5                  : {mrr_5:.4f} \t(Target: >0.7)")
    print(f"Avg Latency             : {avg_latency:.3f} sec \t(Target: <5 seconds)")
    print(f"Latency data points     : {len(latency_entries)}/{total_queries}")
    print(sep)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Evaluate RAG Pipeline Results for BIS Hackathon"
    )
    parser.add_argument(
        "--results",
        type=str,
        required=True,
        help="Path to the participant's output JSON file",
    )
    args = parser.parse_args()
    evaluate_results(args.results)
