"""
BIS Standards Recommendation Engine - Interactive Demo UI

Run:
    python app.py

Requires:
    pip install gradio
    GEMINI_API_KEY set in .env (for rationale generation)
    ChromaDB built via: python src/ingest.py --pdf dataset.pdf
"""

import os
import sys
import threading

_ROOT = os.path.dirname(os.path.abspath(__file__))
_SRC  = os.path.join(_ROOT, "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

import gradio as gr
from retriever import hybrid_retrieve, get_bi_encoder, get_collection, get_bm25_index
from generator import generate_recommendations
from config import FETCH_K, TOP_K
from inference import keyword_rescore, family_rerank

# ---------------------------------------------------------------------------
# Eager warmup in background thread so first user query isn't slow
# ---------------------------------------------------------------------------

def _warmup():
    try:
        enc = get_bi_encoder()
        enc.encode(
            "ordinary portland cement grade 33 chemical physical requirements",
            normalize_embeddings=True,
        )
        get_collection()
        get_bm25_index()
    except Exception as exc:
        print(f"[app] Warmup warning: {exc} — first query may be slower.")

threading.Thread(target=_warmup, daemon=True).start()

# ---------------------------------------------------------------------------
# Core query function
# ---------------------------------------------------------------------------

def search_standards(query: str):
    """Run retrieval + Gemini rationale and return formatted outputs."""
    query = query.strip()
    if not query:
        return "Please enter a product description.", ""

    candidates = hybrid_retrieve(query, top_k=FETCH_K)
    if not candidates:
        return "No results found. Make sure the ChromaDB index is built.", ""
    candidates = keyword_rescore(candidates, query)
    candidates = family_rerank(candidates, query)
    is_codes   = [h["is_code"] for h in candidates][:TOP_K]

    code_to_hit = {h["is_code"]: h for h in candidates}
    hits = [code_to_hit[c] for c in is_codes if c in code_to_hit]

    if not hits:
        return "No results found. Make sure the ChromaDB index is built.", ""

    gen_result      = generate_recommendations(query, hits)
    recommendations = gen_result.get("recommendations", [])
    warning         = gen_result.get("missing_info_warning")
    error           = gen_result.get("error")

    lines = []
    for i, hit in enumerate(hits[:5], 1):
        lines.append(f"**{i}. {hit['is_code']}**  |  Score: {hit['score']:.3f}")
        if hit.get("title"):
            lines.append(f"*{hit['title']}*")
        lines.append("")
    retrieved_md = "\n".join(lines)

    if error:
        rationale_md = (
            f"> Gemini unavailable: {error}\n\n"
            "Set `GEMINI_API_KEY` in your `.env` file to enable rationale generation."
        )
    elif warning:
        rationale_md = f"> {warning}"
    elif recommendations:
        parts = []
        for rec in recommendations:
            parts.append(
                f"### {rec.get('rank', '?')}. {rec.get('is_code', 'N/A')} - "
                f"{rec.get('standard_title', '')}\n"
                f"**Why it applies:** {rec.get('rationale', '')}\n\n"
                f"**Key compliance check:** {rec.get('compliance_key', '')}"
            )
        rationale_md = "\n\n---\n\n".join(parts)
    else:
        rationale_md = "No rationale generated."

    return retrieved_md, rationale_md


# ---------------------------------------------------------------------------
# Example queries
# ---------------------------------------------------------------------------

EXAMPLES = [
    ["We manufacture Portland slag cement for general construction. Which standard applies?"],
    ["Looking for the specification for coarse and fine aggregates for structural concrete."],
    ["We produce precast concrete pipes without reinforcement for water mains."],
    ["Our plant makes hollow lightweight concrete masonry blocks."],
    ["We need the standard for hot-rolled steel bars used as concrete reinforcement."],
]

# ---------------------------------------------------------------------------
# Gradio UI
# ---------------------------------------------------------------------------

with gr.Blocks(title="BIS Standards Recommendation Engine") as demo:

    gr.Markdown(
        """
        # BIS Standards Recommendation Engine
        **Nandan A R | BIS × Sigma Squad AI Hackathon 2026**

        Enter a product description to find the most relevant Bureau of Indian Standards (IS) codes.
        """
    )

    with gr.Row():
        with gr.Column(scale=3):
            query_box = gr.Textbox(
                label="Product Description",
                placeholder="e.g. We manufacture Portland slag cement for general construction use...",
                lines=3,
            )
            submit_btn = gr.Button("Find Standards", variant="primary")

        with gr.Column(scale=1):
            gr.Markdown("**Try an example:**")
            gr.Examples(
                examples=EXAMPLES,
                inputs=query_box,
                label="",
            )

    with gr.Row():
        with gr.Column():
            retrieved_out = gr.Markdown(label="Retrieved Standards")

        with gr.Column():
            rationale_out = gr.Markdown(label="Rationale (Gemini)")

    submit_btn.click(
        fn=search_standards,
        inputs=query_box,
        outputs=[retrieved_out, rationale_out],
    )

    query_box.submit(
        fn=search_standards,
        inputs=query_box,
        outputs=[retrieved_out, rationale_out],
    )

    gr.Markdown(
        """
        ---
        *Retrieval: all-MiniLM-L6-v2 bi-encoder + BM25 keyword rescoring + family reranking over ChromaDB.*
        *Rationale: Gemini 2.5 Flash (requires GEMINI_API_KEY in .env).*
        """
    )

demo.queue()

if __name__ == "__main__":
    demo.launch(share=False, theme=gr.themes.Soft())
