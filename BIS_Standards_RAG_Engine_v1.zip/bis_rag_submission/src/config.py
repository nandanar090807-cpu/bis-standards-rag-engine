"""
Centralised configuration for the BIS RAG pipeline.
All other modules import from here. Nothing is hardcoded elsewhere.
Reads from environment variables (or .env via python-dotenv).

Supported environment variables
--------------------------------
GEMINI_API_KEY      : Required for demo UI and query expansion. Not used during eval.
GEMINI_MODEL        : Gemini model ID (default: gemini-2.5-flash).
DATASET_PATH        : Path to BIS SP 21 PDF (default: ./dataset.pdf).
DB_PATH             : ChromaDB storage directory (default: ./db/chroma).
BI_ENCODER_MODEL    : HuggingFace bi-encoder model (default: all-MiniLM-L6-v2).
CROSS_ENCODER_MODEL : HuggingFace cross-encoder model (default: ms-marco-MiniLM-L-6-v2).
FETCH_K             : Candidates fetched from ChromaDB per query (default: 20, min: 1).
TOP_K               : Standards returned per query (default: 5, min: 1).
EMBED_TEXT_LIMIT    : Body text chars used for embedding (default: 600, min: 50).
STORE_TEXT_LIMIT    : Body text chars stored in ChromaDB (default: 2000, min: 100).
EMBED_BATCH_SIZE    : Batch size for SentenceTransformer.encode() (default: 64, min: 1).
GENERATOR_TIMEOUT   : Gemini API timeout in seconds (default: 15, min: 1).
GENERATOR_TEXT_LIMIT: Chars of body text sent to Gemini per chunk (default: 800).
GENERATOR_MAX_TOKENS: Max output tokens from Gemini (default: 2048).
"""
import os
from dotenv import load_dotenv

load_dotenv()


def _int_env(name: str, default: int, min_val: int = 1) -> int:
    """Read an integer env var with range validation."""
    raw = os.environ.get(name, str(default))
    try:
        val = int(raw)
    except ValueError:
        print(f"[config] WARNING: {name}={raw!r} is not an integer; using default {default}.")
        return default
    if val < min_val:
        print(f"[config] WARNING: {name}={val} is below minimum {min_val}; using {min_val}.")
        return min_val
    return val


# ---- Paths ------------------------------------------------------------------

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")
PDF_PATH = os.environ.get("DATASET_PATH", os.path.join(BASE_DIR, "dataset.pdf"))

# ---- ChromaDB ---------------------------------------------------------------

CHROMA_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "db", "chroma"))
COLLECTION  = "bis_standards"   # single source of truth -- never hardcode elsewhere

# ---- Models -----------------------------------------------------------------

BI_ENCODER_MODEL    = os.environ.get("BI_ENCODER_MODEL",    "all-MiniLM-L6-v2")
CROSS_ENCODER_MODEL = os.environ.get("CROSS_ENCODER_MODEL", "cross-encoder/ms-marco-MiniLM-L-6-v2")

# ---- Gemini (demo UI only -- not used during eval) --------------------------

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
# NOTE: Gemini model IDs may require version suffixes depending on the API tier.
# If you get a 404, try a versioned alias like "gemini-2.5-flash-preview-04-17".
GEMINI_MODEL   = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")

# ---- Retrieval hyperparameters ----------------------------------------------

# FETCH_K: candidates pulled from ChromaDB before family_rerank.
# Keep >= TOP_K so reranking has room to promote the correct Part.
FETCH_K = _int_env("FETCH_K", 20, min_val=1)
TOP_K   = _int_env("TOP_K",    5, min_val=1)

# ---- Ingestion --------------------------------------------------------------

EMBED_TEXT_LIMIT = _int_env("EMBED_TEXT_LIMIT",  600, min_val=50)
STORE_TEXT_LIMIT = _int_env("STORE_TEXT_LIMIT", 2000, min_val=100)
EMBED_BATCH_SIZE = _int_env("EMBED_BATCH_SIZE",   64, min_val=1)

# ---- Generator --------------------------------------------------------------

GENERATOR_TIMEOUT    = _int_env("GENERATOR_TIMEOUT",    15, min_val=1)
GENERATOR_TEXT_LIMIT = _int_env("GENERATOR_TEXT_LIMIT", 800, min_val=50)
GENERATOR_MAX_TOKENS = _int_env("GENERATOR_MAX_TOKENS", 2048, min_val=64)
