"""
Shared retrieval post-processing utilities.

Imported by both inference.py (scoring pipeline) and app.py (demo UI).
Kept in a separate module so app.py does not need to import inference.py,
which would trigger inference.py's module-level signal.signal(SIGINT) call
and override Gradio's own interrupt handling.
"""
import re
from collections import Counter, defaultdict


def keyword_rescore(hits: list, query: str, alpha: float = 0.3) -> list:
    """
    Blend vector similarity with a TF-weighted keyword overlap score.

    Modifies hit dicts in-place (score field). alpha=0.3 means 30% keyword,
    70% incoming score.

    Words shorter than 4 chars are skipped (removes stop words cheaply).
    Document term frequency is capped at 5 to prevent long documents
    from dominating on common words. Keyword score is normalised to [0,1].

    Edge case: if the query contains no words >= 4 chars (e.g. "rcc bar rod"),
    keyword scoring is skipped entirely and scores are returned unchanged.
    """
    query_words = Counter(
        w for w in re.findall(r"[a-zA-Z]+", query.lower()) if len(w) >= 4
    )
    if not query_words:
        return hits

    total_qw = sum(query_words.values())

    for hit in hits:
        doc = (hit.get("title", "") + " " + hit.get("text", "")).lower()
        dc  = Counter(re.findall(r"[a-zA-Z]+", doc))
        raw = sum(min(dc.get(w, 0), 5) * c for w, c in query_words.items()) / total_qw
        kw_score = min(raw / 5.0, 1.0)
        hit["score"] = (1.0 - alpha) * hit["score"] + alpha * kw_score

    hits.sort(key=lambda x: x["score"], reverse=True)
    return hits


def family_rerank(hits: list, query: str) -> list:
    """
    Within hits that share the same IS number family (all IS 2185 Parts,
    all IS 1489 Parts, etc.), promote whichever Part has the highest
    keyword overlap with the query. All other positions are left untouched.

    Operates on the full merged candidate list BEFORE slicing to top_k so
    the correct Part can be promoted even when it ranked below top_k in
    the initial vector retrieval.

    Note: this function can only reorder Parts that were actually fetched.
    If only one Part of a family was retrieved, nothing changes.

    query_tokens includes both letters AND digits so grade numbers ("33"),
    part numbers ("2"), and class identifiers ("4") participate in disambiguation.
    """
    query_tokens = set(
        w for w in re.findall(r"[a-zA-Z0-9]+", query.lower()) if len(w) >= 2
    )

    def is_family(code: str) -> str:
        m = re.match(r"IS\s+(\d+)", code)
        return m.group(1) if m else "__no_family__"

    def overlap(hit: dict) -> int:
        head = (hit.get("title", "") + " " + hit.get("text", "")[:200]).lower()
        tail = hit.get("text", "")[200:].lower()
        hc   = Counter(re.findall(r"[a-zA-Z0-9]+", head))
        tc   = Counter(re.findall(r"[a-zA-Z0-9]+", tail))
        return sum(hc.get(t, 0) * 3 + tc.get(t, 0) for t in query_tokens)

    families: dict = defaultdict(list)
    for i, hit in enumerate(hits):
        families[is_family(hit["is_code"])].append((i, hit))

    reranked = list(hits)
    for members in families.values():
        if len(members) < 2:
            continue
        positions   = sorted(pos for pos, _ in members)
        sorted_hits = sorted(
            (h for _, h in members), key=overlap, reverse=True
        )
        for pos, hit in zip(positions, sorted_hits):
            reranked[pos] = hit

    return reranked
