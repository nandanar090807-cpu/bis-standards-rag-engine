"""
BIS RAG Pipeline - Retriever Module

Hybrid retrieval: bi-encoder semantic search (ChromaDB) + BM25 keyword search,
merged by weighted score combination. Cross-encoder reranking available as an
optional extra pass via the --rerank flag in inference.py.
"""
import os
import re
import sys

_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

import chromadb
from sentence_transformers import SentenceTransformer
from dotenv import load_dotenv

load_dotenv()

from config import (
    BI_ENCODER_MODEL,
    CHROMA_PATH,
    COLLECTION,
    CROSS_ENCODER_MODEL,
    FETCH_K,
)

# ---------------------------------------------------------------------------
# Module-level singletons
# ---------------------------------------------------------------------------
_bi_encoder    = None
_cross_encoder = None
_chroma_client = None
_collection    = None

# BM25 index built lazily from the ChromaDB corpus on first use
_bm25_index  = None
_bm25_corpus = None   # list of dicts in index order


def get_bi_encoder() -> SentenceTransformer:
    global _bi_encoder
    if _bi_encoder is None:
        _bi_encoder = SentenceTransformer(BI_ENCODER_MODEL)
    return _bi_encoder


def get_cross_encoder():
    global _cross_encoder
    if _cross_encoder is None:
        from sentence_transformers import CrossEncoder
        _cross_encoder = CrossEncoder(CROSS_ENCODER_MODEL)
    return _cross_encoder


def get_collection(db_path: str = CHROMA_PATH):
    """
    Return the singleton ChromaDB collection.

    NOTE: db_path is used only on the first call. Subsequent calls return
    the cached collection regardless of db_path. Pass a custom path only
    on the very first call (i.e. before warmup).
    """
    global _chroma_client, _collection
    if _collection is None:
        _chroma_client = chromadb.PersistentClient(path=db_path)
        _collection = _chroma_client.get_collection(COLLECTION)
    return _collection


def _tokenize(text: str) -> list:
    """Lowercase word tokenizer. Drops tokens shorter than 3 chars."""
    return [w for w in re.findall(r"[a-zA-Z0-9]+", text.lower()) if len(w) >= 3]


def get_bm25_index():
    """
    Build (once) a BM25Okapi index over the full ChromaDB corpus.
    Each document is: is_code + title + stored body text.
    Returns (BM25Okapi index, corpus list of dicts).

    Called from warmup() so the build cost is paid before inference starts,
    not during the first real query.
    """
    global _bm25_index, _bm25_corpus
    if _bm25_index is not None:
        return _bm25_index, _bm25_corpus

    from rank_bm25 import BM25Okapi

    collection = get_collection()
    total = collection.count()
    if total == 0:
        return None, []

    all_results = collection.get(
        include=["documents", "metadatas"],
        limit=total,
    )

    _bm25_corpus = []
    tokenized_docs = []
    for i in range(len(all_results["ids"])):
        meta = all_results["metadatas"][i]
        doc  = all_results["documents"][i]
        is_code = meta.get("is_code", "")
        title   = meta.get("title",   "")
        full_text = f"{is_code} {title} {doc}"
        _bm25_corpus.append({"is_code": is_code, "title": title, "text": doc})
        tokenized_docs.append(_tokenize(full_text))

    _bm25_index = BM25Okapi(tokenized_docs)
    print(f"[retriever] BM25 index built over {total} standards.")
    return _bm25_index, _bm25_corpus


def bm25_retrieve(query: str, top_k: int = FETCH_K) -> list:
    """BM25 keyword retrieval. Returns top_k hits with bm25_score key."""
    bm25, corpus = get_bm25_index()
    if bm25 is None or not corpus:
        return []
    tokens = _tokenize(query)
    if not tokens:
        return []
    scores = bm25.get_scores(tokens)
    if max(scores) == 0.0:
        print("[retriever] BM25: all scores zero for this query — falling back to vector-only.")
    top_indices = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:top_k]
    return [
        {"is_code": corpus[i]["is_code"], "title": corpus[i]["title"],
         "text": corpus[i]["text"], "bm25_score": float(scores[i])}
        for i in top_indices
    ]


# ---------------------------------------------------------------------------
# Semantic retrieval
# ---------------------------------------------------------------------------

def retrieve(query: str, top_k: int = FETCH_K, rerank: bool = False,
             category=None) -> list:
    """
    Pure bi-encoder semantic search over ChromaDB.
    Returns list of dicts with keys: is_code, title, text, score.
    """
    if not query or not query.strip():
        return []

    bi_enc     = get_bi_encoder()
    collection = get_collection()

    total_indexed = collection.count()
    if total_indexed == 0:
        print("[retriever] WARNING: Collection is empty. Run ingest first.")
        return []

    n_results = min(top_k, total_indexed)
    query_emb = bi_enc.encode(query, normalize_embeddings=True).tolist()

    where_filter = {"category": category} if category else None
    query_kwargs = dict(
        query_embeddings=[query_emb],
        n_results=n_results,
        include=["documents", "metadatas", "distances"],
    )
    if where_filter:
        query_kwargs["where"] = where_filter

    results = collection.query(**query_kwargs)

    ids_list = results.get("ids", [[]])
    if not ids_list or not ids_list[0]:
        return []

    hits = []
    for i in range(len(ids_list[0])):
        distance   = results["distances"][0][i]
        similarity = max(0.0, 1.0 - distance)  # ChromaDB cosine: distance = 1 - cosine_sim
        hits.append({
            "is_code": results["metadatas"][0][i]["is_code"],
            "title":   results["metadatas"][0][i]["title"],
            "text":    results["documents"][0][i],
            "score":   round(similarity, 4),
        })

    if rerank and len(hits) > 1:
        ce = get_cross_encoder()
        pairs = [(query, f"{h['is_code']} {h['title']} {h['text'][:400]}") for h in hits]
        ce_scores = ce.predict(pairs)
        for i, h in enumerate(hits):
            h["ce_score"] = float(ce_scores[i])
        hits.sort(key=lambda x: x["ce_score"], reverse=True)

    return hits[:top_k]


# ---------------------------------------------------------------------------
# Category detection for metadata-filtered retrieval
# ---------------------------------------------------------------------------

_QUERY_CATEGORY_KEYWORDS = {
    "cement":    ["cement", "portland", "clinker", "pozzolana", "slag", "fly ash", "flyash"],
    "aggregate": ["aggregate", "gravel", "sand", "coarse", "fine aggregate", "fineaggregate",
                  "crushed stone"],
    "steel":     ["steel", "reinforcement", "rebar", r"\bbar\b", "wire", "strand", "tendon"],
    "concrete":  ["concrete", "mortar", "masonry", "grout", "screed", "precast", "block"],
    "brick":     ["brick", "tile", "clay", "burnt clay"],
    "pipe":      ["pipe", "tube", "culvert", "conduit", "drainage"],
}


def detect_category(query: str):
    """
    Infer a category from the query string using keyword matching.
    Returns a category string or None (no filter applied).
    """
    q = query.lower()
    for cat, keywords in _QUERY_CATEGORY_KEYWORDS.items():
        if any(re.search(kw, q) for kw in keywords):
            return cat
    return None


def hybrid_retrieve(query: str, top_k: int = FETCH_K, alpha: float = 0.15,
                    category=None, rerank: bool = False) -> list:
    """
    Hybrid retrieval: combine bi-encoder vector scores with BM25 keyword scores.

    alpha=0.15 means 15% BM25, 85% semantic (default).
    BM25 scores are normalised to [0,1] before blending.
    Union of both candidate sets is scored; missing source gets 0.

    Note: with alpha=0.15, a BM25-only hit needs a near-perfect BM25 score
    to outrank even a weak vector hit. BM25 primarily serves as a tie-breaker
    when the same code appears in both result sets.
    """
    if not query or not query.strip():
        return []

    vec_hits  = retrieve(query, top_k=top_k, category=category, rerank=rerank)
    bm25_hits = bm25_retrieve(query, top_k=top_k)

    vec_map: dict  = {h["is_code"]: h for h in vec_hits}
    max_bm25 = max((h["bm25_score"] for h in bm25_hits), default=1.0) or 1.0
    bm25_map: dict = {h["is_code"]: h["bm25_score"] / max_bm25 for h in bm25_hits}

    all_codes = set(vec_map) | set(bm25_map)
    merged = []
    for code in all_codes:
        vec_score  = vec_map[code]["score"] if code in vec_map else 0.0
        bm25_score = bm25_map.get(code, 0.0)
        combined   = (1.0 - alpha) * vec_score + alpha * bm25_score
        base = vec_map[code] if code in vec_map else next(
            h for h in bm25_hits if h["is_code"] == code
        )
        merged.append({
            "is_code": code,
            "title":   base["title"],
            "text":    base["text"],
            "score":   round(combined, 4),
        })

    import heapq
    top = heapq.nlargest(top_k, merged, key=lambda x: x["score"])
    return top
