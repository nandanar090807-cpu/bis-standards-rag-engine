"""
BIS RAG Pipeline - Ingestion Script
Parses BIS SP 21 PDF, chunks by IS standard, embeds and stores in ChromaDB.

Usage:
    python src/ingest.py
    python src/ingest.py --pdf /path/to/dataset.pdf --db /path/to/db

Environment overrides (alternative to CLI flags):
    DATASET_PATH=/path/to/dataset.pdf
    DB_PATH=./db/chroma
"""
import argparse
import json
import os
import re
import sys

_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

import chromadb
import fitz  # pymupdf
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer

load_dotenv()

from config import (
    BI_ENCODER_MODEL,
    CHROMA_PATH,
    COLLECTION,
    DATA_DIR,
    EMBED_BATCH_SIZE,
    EMBED_TEXT_LIMIT,
    PDF_PATH,
    STORE_TEXT_LIMIT,
)

# ---------------------------------------------------------------------------
# Regex: matches IS codes like "IS 383 : 1970", "IS 2185 (PART 2) : 1983"
# Group 1 = IS code, Group 2 = title (may be empty)
# ---------------------------------------------------------------------------
_IS_CODE_RE = re.compile(
    r"^(IS\s+\d+(?:\s*\([^)]+\))?\s*:\s*\d{4})\s*(.*)"
)

# Lines matching this pattern are PDF header/footer artefacts to drop.
# Covers: "SP 21 : 2005", "SP 21:2005", standalone page numbers like "42".
_HEADER_RE = re.compile(r"^(?:SP\s*21\b.*|\d+)$", re.IGNORECASE)

# Collapsed hyphen: "manufac- turing" -> "manufacturing"
_HYPHEN_RE = re.compile(r"([a-zA-Z])-\s+([a-zA-Z])")


def normalize_is_code(code: str) -> str:
    """
    Normalise IS code strings copied verbatim from the PDF.

    Fixes applied:
        IS455:1989         -> IS 455 : 1989   (space after IS prefix)
        PART2              -> PART 2           (single AND multi-digit)
        PART11             -> PART 11          (regex captures full digit run)
        1989:              -> 1989 :           (space before colon)
        :1989              -> : 1989           (space after colon)
        Multiple spaces    -> single space
    """
    code = re.sub(r"\s+", " ", code).strip()
    code = re.sub(r"^IS(\d)", r"IS \1", code)
    code = re.sub(r"PART(\d+)", r"PART \1", code)
    code = re.sub(r"(\S):", r"\1 :", code)
    code = re.sub(r":\s*(\d)", r": \1", code)
    code = re.sub(r"\s+", " ", code).strip()
    return code


def _is_header(line: str) -> bool:
    return bool(_HEADER_RE.match(line))


def _resolve_hyphens(text: str) -> str:
    """Join words hyphenated across PDF line breaks: 'manufac- turing' -> 'manufacturing'."""
    return _HYPHEN_RE.sub(r"\1\2", text)


def parse_pdf(pdf_path: str) -> list:
    """
    Parse BIS SP 21 PDF into one dict per IS standard.

    Each dict has keys:
        is_code  str   normalised IS code, e.g. "IS 383 : 1970"
        title    str   standard title from the header line
        text     str   body text of the standard summary
    """
    chunks = []
    seen_codes: set = set()
    current_is_code = None
    current_title   = None
    current_lines   = []
    next_is_summary = False

    try:
        doc = fitz.open(pdf_path)
    except Exception as exc:
        print(f"[ingest] ERROR: Cannot open '{pdf_path}': {exc}")
        sys.exit(1)

    print(f"[ingest] Parsing {len(doc)} pages ...")

    try:
        for page in doc:
            raw_text = page.get_text()
            if not raw_text or not raw_text.strip():
                continue

            for line in raw_text.split("\n"):
                line = line.strip()

                if not line or _is_header(line):
                    continue

                if re.match(r"^SUMMARY\s+OF$", line):   # always uppercase in BIS SP 21
                    if current_is_code and current_lines:
                        body = _resolve_hyphens(" ".join(current_lines)).strip()
                        # Normalise double spaces introduced by PDF extraction
                        body = re.sub(r"  +", " ", body)
                        if body and current_is_code not in seen_codes:
                            chunks.append({
                                "is_code": current_is_code,
                                "title":   current_title,
                                "text":    body,
                            })
                            seen_codes.add(current_is_code)

                    current_is_code = None
                    current_title   = None
                    current_lines   = []
                    next_is_summary = True

                elif next_is_summary:
                    m = _IS_CODE_RE.match(line)
                    if m:
                        current_is_code = normalize_is_code(m.group(1))
                        current_title   = m.group(2).strip()
                        if not current_title:
                            print(f"[ingest] WARNING: empty title for {current_is_code}")
                        current_lines   = []
                        next_is_summary = False

                else:
                    if current_is_code:
                        current_lines.append(line)

    finally:
        doc.close()

    # Flush the last standard after the final page
    if current_is_code and current_lines:
        body = _resolve_hyphens(" ".join(current_lines)).strip()
        body = re.sub(r"  +", " ", body)
        if body and current_is_code not in seen_codes:
            chunks.append({
                "is_code": current_is_code,
                "title":   current_title,
                "text":    body,
            })

    print(f"[ingest] Parsed {len(chunks)} IS standards.")
    return chunks


# Shared category keywords — single source of truth for ingest classification.
# retriever.py and generate_eval.py should import from here rather than redefine.
CATEGORY_KEYWORDS = {
    "cement":    ["cement", "portland", "clinker", "pozzolana", "slag cement",
                  "fly ash", "flyash"],
    "aggregate": ["aggregate", "gravel", "sand", "coarse", "fine aggr",
                  "fineaggregate", "crushed stone"],
    "steel":     ["steel", "reinforcement", "rebar", r"\bbar\b", "wire",
                  "strand", "tendon"],
    "concrete":  ["concrete", "mortar", "masonry", "grout", "screed",
                  "precast", "block"],
    "brick":     ["brick", "tile", "clay", "burnt clay", "earthenware"],
    "pipe":      ["pipe", "tube", "culvert", "conduit", "drainage"],
}


def classify_standard(chunk: dict) -> str:
    """
    Assign a category label to a BIS standard chunk based on keyword matching.
    Returns the first matching category, or 'general' if none match.

    Note: keywords are matched as substrings or regex patterns in the combined
    title + body text. Category order determines priority when multiple match.
    """
    text = (chunk.get("title", "") + " " + chunk.get("text", "")).lower()
    for cat, keywords in CATEGORY_KEYWORDS.items():
        if any(re.search(kw, text) for kw in keywords):
            return cat
    return "general"


def build_vector_store(chunks: list, chroma_path: str = CHROMA_PATH) -> None:
    """Embed all chunks and write them to a ChromaDB persistent collection."""
    if not chunks:
        print("[ingest] ERROR: No chunks parsed from PDF. Aborting.")
        sys.exit(1)

    print(f"[ingest] Loading bi-encoder: {BI_ENCODER_MODEL} ...")
    model = SentenceTransformer(BI_ENCODER_MODEL)

    os.makedirs(chroma_path, exist_ok=True)
    client = chromadb.PersistentClient(path=chroma_path)

    try:
        client.delete_collection(COLLECTION)
        print(f"[ingest] Dropped existing collection '{COLLECTION}'.")
    except Exception:
        print("[ingest] No existing collection. Creating fresh.")

    collection = client.create_collection(
        COLLECTION,
        metadata={"hnsw:space": "cosine"},
    )

    embed_texts = [
        f"{c['is_code']} {c['title']} {c['text'][:EMBED_TEXT_LIMIT]}"
        for c in chunks
    ]
    ids       = [f"std_{i}" for i in range(len(chunks))]
    metadatas = [
        {"is_code": c["is_code"], "title": c["title"], "category": classify_standard(c)}
        for c in chunks
    ]
    documents = [c["text"][:STORE_TEXT_LIMIT] for c in chunks]

    print(f"[ingest] Embedding {len(chunks)} standards ...")
    embeddings = model.encode(
        embed_texts,
        batch_size=EMBED_BATCH_SIZE,
        normalize_embeddings=True,
        show_progress_bar=True,
    ).tolist()

    collection.add(
        ids=ids,
        embeddings=embeddings,
        metadatas=metadatas,
        documents=documents,
    )

    # Verify the collection was populated correctly
    stored = collection.count()
    if stored != len(chunks):
        print(f"[ingest] WARNING: expected {len(chunks)} documents but ChromaDB shows {stored}.")
    else:
        print(f"[ingest] Verified: {stored} standards stored in ChromaDB.")

    print(f"[ingest] Done.")
    print(f"[ingest]   Standards indexed : {stored}")
    print(f"[ingest]   ChromaDB path     : {chroma_path}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="BIS SP 21 Ingestion Pipeline",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--pdf", default=PDF_PATH,
        help="Path to BIS SP 21 PDF (default reads DATASET_PATH env var or './dataset.pdf')",
    )
    parser.add_argument(
        "--db", default=CHROMA_PATH,
        help="ChromaDB storage directory",
    )
    args = parser.parse_args()

    if not os.path.exists(args.pdf):
        print(f"[ingest] ERROR: PDF not found at '{args.pdf}'")
        print("Set DATASET_PATH env var or use --pdf /path/to/dataset.pdf")
        sys.exit(1)

    chunks = parse_pdf(args.pdf)
    build_vector_store(chunks, chroma_path=args.db)


if __name__ == "__main__":
    main()
