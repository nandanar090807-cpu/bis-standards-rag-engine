"""
Gemini rationale generator and query expander.

generate_recommendations() -- used by demo UI (app.py) only.
expand_query()              -- used by inference.py when GEMINI_API_KEY is set.

Neither function is called during judge scoring if GEMINI_API_KEY is unset.
"""
import json
import logging
import os
import re
import sys
import time

import requests
from dotenv import load_dotenv

load_dotenv()

_SRC_DIR = os.path.dirname(os.path.abspath(__file__))
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from config import (
    GEMINI_API_KEY,
    GEMINI_MODEL,
    GENERATOR_MAX_TOKENS,
    GENERATOR_TEXT_LIMIT,
    GENERATOR_TIMEOUT,
)

logger = logging.getLogger(__name__)

# Key is sent via header, not URL, to avoid exposure in logs and shell history.
# NOTE: GEMINI_MODEL may require a version suffix depending on your API tier,
# e.g. "gemini-2.5-flash-preview-04-17". If you get a 404, check the model ID.
GEMINI_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

_SYSTEM_PROMPT = """\
You are a BIS compliance analyst specialising in Building Materials \
(Cement, Steel, Concrete, Aggregates). Map product descriptions to Indian \
Standard (IS) codes.

RULES:
1. Only recommend standards explicitly present in the RETRIEVED CONTEXT.
   Do not invent IS codes or numbers.
2. If the context contains no relevant standard, return:
   {"recommendations": [], "missing_info_warning": "No matching standard found in context."}
3. Return ONLY valid JSON. No markdown fences, no preamble, no trailing text.
4. Return between 3 and 5 recommendations.

OUTPUT SCHEMA:
{
  "recommendations": [
    {
      "rank": 1,
      "is_code": "IS 269 : 1989",
      "standard_title": "ORDINARY PORTLAND CEMENT, 33 GRADE",
      "rationale": "Why this standard applies.",
      "compliance_key": "Critical test or parameter to satisfy."
    }
  ],
  "missing_info_warning": null
}\
"""

# Strip markdown fences: ```json ... ``` or ``` ... ```
# Uses a conservative pattern that only strips fences at line boundaries
# to avoid corrupting backtick characters inside JSON string values.
_FENCE_RE = re.compile(r"^```(?:json)?\s*\n|^```\s*$", re.MULTILINE)

_MAX_RETRIES = 3   # total attempts (not retries-after-first)
_RETRY_DELAY = 2   # base seconds; HTTP errors use progressive (_RETRY_DELAY * attempt)


def _make_headers() -> dict:
    return {
        "Content-Type":   "application/json",
        "x-goog-api-key": GEMINI_API_KEY,
    }


def generate_recommendations(query: str, retrieved_chunks: list) -> dict:
    """
    Call Gemini to produce a ranked list of BIS standard recommendations.

    Parameters
    ----------
    query             : product description string
    retrieved_chunks  : list of dicts from retriever.retrieve()

    Returns
    -------
    Dict with key "recommendations" (list) and optional "error" or
    "missing_info_warning" keys.
    """
    if not GEMINI_API_KEY:
        return {"recommendations": [], "error": "GEMINI_API_KEY not set in .env"}

    if not retrieved_chunks:
        return {"recommendations": [], "error": "No retrieved chunks provided."}

    context_parts = []
    for i, chunk in enumerate(retrieved_chunks, 1):
        context_parts.append(
            f"[CONTEXT {i}] {chunk['is_code']} - {chunk.get('title', '')}\n"
            f"{chunk.get('text', '')[:GENERATOR_TEXT_LIMIT]}"
        )
    context = "\n\n".join(context_parts)

    user_content = (
        f"[PRODUCT DESCRIPTION]\n{query}\n\n"
        f"[RETRIEVED CONTEXT]\n{context}\n\n"
        "Return 3-5 applicable standards from the retrieved context only. "
        "Strict JSON, no explanation outside the JSON object."
    )

    payload = {
        "system_instruction": {"parts": [{"text": _SYSTEM_PROMPT}]},
        "contents": [{"role": "user", "parts": [{"text": user_content}]}],
        "generationConfig": {
            "temperature":     0.1,
            "maxOutputTokens": GENERATOR_MAX_TOKENS,
        },
    }

    last_error = "Unknown error"

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            resp = requests.post(
                GEMINI_URL,
                json=payload,
                headers=_make_headers(),
                timeout=GENERATOR_TIMEOUT,
            )

            if resp.status_code == 200:
                data       = resp.json()
                candidates = data.get("candidates", [])
                if not candidates:
                    return {
                        "recommendations": [],
                        "error": "Gemini returned no candidates (safety filter or quota).",
                    }
                try:
                    raw = candidates[0]["content"]["parts"][0]["text"].strip()
                except (KeyError, IndexError) as exc:
                    return {"recommendations": [], "error": f"Unexpected API response shape: {exc}"}

                raw = _FENCE_RE.sub("", raw).strip()

                try:
                    return json.loads(raw)
                except json.JSONDecodeError as exc:
                    return {"recommendations": [], "error": f"JSON parse failed: {exc}. Raw: {raw[:200]}"}

            if resp.status_code in (429, 500, 503):
                last_error = f"HTTP {resp.status_code} (attempt {attempt})"
                time.sleep(_RETRY_DELAY * attempt)   # progressive backoff
                continue

            last_error = f"HTTP {resp.status_code}: {resp.text[:300]}"
            break

        except requests.Timeout:
            last_error = f"Timeout after {GENERATOR_TIMEOUT}s (attempt {attempt})"
            time.sleep(_RETRY_DELAY * attempt)   # progressive backoff for timeouts too

        except requests.RequestException as exc:
            last_error = f"Request error: {exc}"
            break

    return {"recommendations": [], "error": last_error}


# ---------------------------------------------------------------------------
# Query expansion
# ---------------------------------------------------------------------------

_EXPAND_SYSTEM = (
    "You are a BIS compliance expert specialising in Indian Standards for "
    "Building Materials (cement, steel, concrete, aggregates). "
    "Given a product description, return ONLY a JSON array of exactly 3 strings: "
    "3 rewrites of the query using official BIS/IS domain terminology. "
    "Do NOT include the original query — return only the 3 rewrites. "
    "No explanation, no markdown fences, just the raw JSON array."
)


def expand_query(query: str) -> list:
    """
    Use Gemini to produce 3 BIS-domain rewrites of *query*.

    Returns [query] + up to 3 variants on success (4 total),
    or [query] on any failure (missing API key, timeout, parse error).
    The fallback ensures the inference pipeline is never blocked.
    """
    if not GEMINI_API_KEY:
        return [query]

    payload = {
        "system_instruction": {"parts": [{"text": _EXPAND_SYSTEM}]},
        "contents": [{"role": "user", "parts": [{"text": query}]}],
        "generationConfig": {"temperature": 0.2, "maxOutputTokens": 512},
    }

    try:
        resp = requests.post(
            GEMINI_URL,
            json=payload,
            headers=_make_headers(),
            timeout=GENERATOR_TIMEOUT,
        )
        if resp.status_code != 200:
            logger.warning("expand_query HTTP %s", resp.status_code)
            return [query]

        data = resp.json()
        candidates = data.get("candidates", [])
        if not candidates:
            return [query]

        raw = candidates[0]["content"]["parts"][0]["text"].strip()
        raw = _FENCE_RE.sub("", raw).strip()
        variants = json.loads(raw)

        if isinstance(variants, list) and all(isinstance(v, str) for v in variants):
            seen = set()
            result = []
            for v in [query] + variants:
                if v not in seen:
                    seen.add(v)
                    result.append(v)
            return result[:4]   # original + up to 3 variants

        return [query]

    except json.JSONDecodeError as exc:
        logger.warning("expand_query JSON parse failed: %s", exc)
        return [query]
    except requests.RequestException as exc:
        logger.warning("expand_query request failed: %s", exc)
        return [query]
    except Exception as exc:
        logger.warning("expand_query unexpected error: %s", exc)
        return [query]
