"""
BIS Standards Recommendation Engine - Inference Entry Point

Judge command:
    python inference.py --input hidden_private_dataset.json --output team_results.json

Optional flags:
    --fetch-k INT   Candidates fetched from ChromaDB per query (default: 20)
    --top-k   INT   Standards returned in output (default: 5)
    --rerank        Enable cross-encoder reranking (off by default; adds ~500ms/query)

Pipeline
--------
query
  -> expand_query   (Gemini rewrites; falls back to [query] if no API key)
  -> hybrid_retrieve per variant (bi-encoder + BM25 blend, alpha=0.15)
  -> merge variants by best score per IS code
  -> keyword_rescore   (blends merged score with TF-weighted keyword overlap, alpha=0.3)
  -> family_rerank     (within IS-number families, promote correct Part)
  -> top_k IS codes written to output JSON

Latency note
------------
The reported 0.030s average is measured WITHOUT query expansion (no GEMINI_API_KEY).
With a key set, each query includes a Gemini round-trip (~1-3s extra).
Both modes satisfy the <5s target; set GEMINI_API_KEY only if you want richer retrieval.
"""
import argparse
import json
import os
import re
import signal
import sys
import time
from collections import Counter, defaultdict

_ROOT = os.path.dirname(os.path.abspath(__file__))
_SRC  = os.path.join(_ROOT, "src")
if _SRC not in sys.path:
    sys.path.insert(0, _SRC)

from config import FETCH_K, TOP_K, GEMINI_API_KEY
from retriever import hybrid_retrieve, get_bi_encoder, get_collection, get_bm25_index
from generator import expand_query

# ---------------------------------------------------------------------------
# Graceful shutdown: save whatever was collected before Ctrl-C
# ---------------------------------------------------------------------------

_shutdown = False

def _sigint_handler(sig, frame):
    global _shutdown
    print("\n[inference] Interrupt received. Saving partial results ...", flush=True)
    _shutdown = True

signal.signal(signal.SIGINT, _sigint_handler)

# ---------------------------------------------------------------------------
# Warmup
# ---------------------------------------------------------------------------

def warmup() -> None:
    """
    Load models and prime ChromaDB + BM25 before the timed inference loop.

    Primes three costs that would otherwise hit the first real query:
      1. SentenceTransformer model load
      2. PyTorch JIT compilation (via a realistic dummy encode)
      3. BM25 index construction from ChromaDB corpus
    """
    print("[warmup] Loading bi-encoder and priming JIT ...", flush=True)
    enc = get_bi_encoder()
    # Use a realistic-length string so JIT compiles for the actual sequence length
    enc.encode(
        "ordinary portland cement grade 33 chemical physical requirements",
        normalize_embeddings=True,
    )

    print("[warmup] Connecting to ChromaDB ...", flush=True)
    try:
        col = get_collection()
        count = col.count()
        if count == 0:
            print("[warmup] ERROR: Collection is empty. Run: python src/ingest.py")
            sys.exit(1)
    except Exception as exc:
        print(f"[warmup] ERROR: Cannot open ChromaDB collection: {exc}")
        print("[warmup] Run: python src/ingest.py")
        sys.exit(1)

    print("[warmup] Building BM25 index ...", flush=True)
    get_bm25_index()

    print(f"[warmup] Ready. {count} standards indexed.\n", flush=True)

# ---------------------------------------------------------------------------
# Keyword rescoring
# ---------------------------------------------------------------------------

def keyword_rescore(hits: list, query: str, alpha: float = 0.3) -> list:
    """
    Blend vector similarity with a TF-weighted keyword overlap score.

    Modifies hit dicts in-place (score field). alpha=0.3 means 30% keyword,
    70% incoming score.

    Words shorter than 4 chars are skipped (removes stop words cheaply).
    Document term frequency is capped at 5 to prevent long documents
    from dominating on common words. Keyword score is normalised to [0,1].

    Edge case: if the query contains no words >= 4 chars (e.g. "rcc bar rod"),
    keyword scoring is skipped entirely and scores are returned unchanged.
    """
    query_words = Counter(
        w for w in re.findall(r"[a-zA-Z]+", query.lower()) if len(w) >= 4
    )
    if not query_words:
        # No scoreable tokens — skip rescoring to avoid silent 30% score reduction
        return hits

    total_qw = sum(query_words.values())

    for hit in hits:
        doc = (hit.get("title", "") + " " + hit.get("text", "")).lower()
        dc  = Counter(re.findall(r"[a-zA-Z]+", doc))
        raw = sum(min(dc.get(w, 0), 5) * c for w, c in query_words.items()) / total_qw
        kw_score = min(raw / 5.0, 1.0)
        hit["score"] = (1.0 - alpha) * hit["score"] + alpha * kw_score

    hits.sort(key=lambda x: x["score"], reverse=True)
    return hits

# ---------------------------------------------------------------------------
# Family reranking
# ---------------------------------------------------------------------------

def family_rerank(hits: list, query: str) -> list:
    """
    Within hits that share the same IS number family (all IS 2185 Parts,
    all IS 1489 Parts, etc.), promote whichever Part has the highest
    keyword overlap with the query. All other positions are left untouched.

    Operates on the full merged candidate list BEFORE slicing to top_k so
    the correct Part can be promoted even when it ranked below top_k in
    the initial vector retrieval.

    Note: this function can only reorder Parts that were actually fetched.
    If only one Part of a family was retrieved, nothing changes.

    query_tokens includes both letters AND digits so grade numbers ("33"),
    part numbers ("2"), and class identifiers ("4") participate in disambiguation.
    """
    query_tokens = set(
        w for w in re.findall(r"[a-zA-Z0-9]+", query.lower()) if len(w) >= 2
    )

    def is_family(code: str) -> str:
        m = re.match(r"IS\s+(\d+)", code)
        return m.group(1) if m else "__no_family__"

    def overlap(hit: dict) -> int:
        head = (hit.get("title", "") + " " + hit.get("text", "")[:200]).lower()
        tail = hit.get("text", "")[200:].lower()
        hc   = Counter(re.findall(r"[a-zA-Z0-9]+", head))
        tc   = Counter(re.findall(r"[a-zA-Z0-9]+", tail))
        return sum(hc.get(t, 0) * 3 + tc.get(t, 0) for t in query_tokens)

    families: dict = defaultdict(list)
    for i, hit in enumerate(hits):
        families[is_family(hit["is_code"])].append((i, hit))

    reranked = list(hits)
    for members in families.values():
        if len(members) < 2:
            continue
        positions   = sorted(pos for pos, _ in members)
        sorted_hits = sorted(
            (h for _, h in members), key=overlap, reverse=True
        )
        for pos, hit in zip(positions, sorted_hits):
            reranked[pos] = hit

    return reranked

# ---------------------------------------------------------------------------
# Deduplication
# ---------------------------------------------------------------------------

def deduplicate(codes: list) -> list:
    seen: set = set()
    out:  list = []
    for c in codes:
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out

# ---------------------------------------------------------------------------
# Core inference loop
# ---------------------------------------------------------------------------

def run_inference(
    input_path:  str,
    output_path: str,
    fetch_k:     int  = FETCH_K,
    top_k:       int  = TOP_K,
    use_rerank:  bool = False,
) -> None:
    global _shutdown
    _shutdown = False   # reset so run_inference() is safe to call multiple times

    # Load and validate input
    try:
        with open(input_path, encoding="utf-8") as fh:
            queries = json.load(fh)
    except FileNotFoundError:
        print(f"[inference] ERROR: Input file not found: '{input_path}'")
        sys.exit(1)
    except json.JSONDecodeError as exc:
        print(f"[inference] ERROR: Input is not valid JSON: {exc}")
        sys.exit(1)

    if not queries:
        print("[inference] ERROR: Input file contains no queries.")
        sys.exit(1)

    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)

    warmup()

    results:    list = []
    latencies:  list = []
    skipped:    int  = 0
    total:      int  = len(queries)

    for idx, item in enumerate(queries):
        if _shutdown:
            print("[inference] Shutdown requested. Writing partial results ...")
            break

        qid   = item.get("id",    f"UNK-{idx + 1}")
        query = item.get("query", "").strip()

        if not query:
            print(f"[{idx + 1}/{total}] {qid}: SKIP (empty query)")
            skipped += 1
            continue

        ellipsis = "..." if len(query) > 70 else ""
        print(f"[{idx + 1}/{total}] {qid}: {query[:70]}{ellipsis}")

        # time.perf_counter() is monotonic and high-resolution.
        # time.time() is wall-clock and can go backwards on NTP adjustments.
        t0 = time.perf_counter()

        # Query expansion: only called when GEMINI_API_KEY is set.
        # Without a key, expand_query immediately returns [query] — but we skip
        # the call entirely to avoid the import/function-call overhead per query.
        if GEMINI_API_KEY:
            variants = expand_query(query)
        else:
            variants = [query]

        # Hybrid retrieval for each variant; merge by best score per is_code.
        merged_map: dict = {}
        for variant in variants:
            for hit in hybrid_retrieve(variant, top_k=fetch_k, rerank=use_rerank):
                code = hit["is_code"]
                if code not in merged_map or hit["score"] > merged_map[code]["score"]:
                    merged_map[code] = hit

        candidates = sorted(merged_map.values(), key=lambda x: x["score"], reverse=True)
        candidates = keyword_rescore(candidates, query)
        candidates = family_rerank(candidates, query)
        is_codes   = [h["is_code"] for h in candidates][:top_k]

        latency = round(time.perf_counter() - t0, 3)
        latencies.append(latency)

        results.append({
            "id":                  qid,
            "query":               query,
            "expected_standards":  item.get("expected_standards", []),
            "retrieved_standards": is_codes,
            "latency_seconds":     latency,
        })
        print(f"  -> {is_codes[:3]} | {latency:.3f}s")

    # Atomic write: write to .tmp then os.replace() to avoid partial output files
    tmp_path = output_path + ".tmp"
    try:
        with open(tmp_path, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2, ensure_ascii=False)
        os.replace(tmp_path, output_path)
    except Exception as exc:
        print(f"[inference] ERROR: Cannot write '{output_path}': {exc}")
        sys.exit(1)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass

    processed = len(latencies)
    avg = sum(latencies) / processed if processed else 0.0
    print(f"\nDone. {len(results)} results -> '{output_path}'")
    if skipped:
        print(f"Skipped: {skipped} empty queries (total input: {total})")
    print(f"Avg latency: {avg:.3f}s  (n={processed} queries)")

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="BIS RAG Inference",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument("--input",   required=True,
                        help="Path to input JSON test set")
    parser.add_argument("--output",  required=True,
                        help="Path to write output JSON results")
    parser.add_argument("--fetch-k", type=int, default=FETCH_K,
                        help="Candidates fetched from ChromaDB per query")
    parser.add_argument("--top-k",   type=int, default=TOP_K,
                        help="Standards returned per query")
    parser.add_argument("--rerank",  action="store_true",
                        help="Enable cross-encoder reranking (adds ~500ms/query)")
    args = parser.parse_args()
    run_inference(
        input_path  = args.input,
        output_path = args.output,
        fetch_k     = args.fetch_k,
        top_k       = args.top_k,
        use_rerank  = args.rerank,
    )
